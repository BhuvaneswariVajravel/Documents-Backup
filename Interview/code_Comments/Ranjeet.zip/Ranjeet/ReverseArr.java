package com.coforge.test;

import java.util.Arrays;

public class ReverseArr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] arr= {1,2,3,4,5,6,7,8};
		reverseArr(arr);

	}
	
	static void reverseArr(int[] arr) {
		
		int i=0;
		int j=arr.length-1;
		int res=0;
		Integer[] arrNew = new Integer[j+1];
		while(i<=j) {
			arrNew[res]=arr[j];
			j--;
			res++;
		}
		
		System.out.println(Arrays.toString(arrNew));
	}

}
