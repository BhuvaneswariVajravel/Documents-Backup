package com.coforge.test;

import java.util.*;

public class ImmutableClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String, String> map = new HashMap<>();		
        map.put("1", "first");
        map.put("2", "second");
		
		Student s=new Student("abc", 101,map);
		
		System.out.println(s.getName());
		System.out.println(s.getRegNo());
		//System.out.println(s.getMetadata());
		
		map.put("3", "third");
		//System.out.println(s.getMetadata());
		s.getMetadata().put("4", "fourth");
		System.out.println(s.getMetadata());
		

	}

}
