package com.coforge.test;

public class Anagram {

	static int NO_OF_CHARS=256;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * int[] count =new int[NO_OF_CHARS]; char[] str1="bcd".toCharArray(); for(int
		 * i=0;i<3;i++) { //System.out.println(str1[i]-'a');
		 * System.out.println(count[str1[i]- 'a']++);
		 * 
		 * } System.out.println();
		 */
		System.out.println('j'-'a');
		char[] str1="abcdefjk".toCharArray();
		char[] str2="jkdefcba".toCharArray();
		
		System.out.println(isAnagram(str1, str2));
		
	}
	
	static boolean isAnagram(char[] str1,char[] str2) {
		
		int[] count =new int[NO_OF_CHARS];
		int i;
		
		for(i=0;i<str1.length;i++) {
			count[str1[i]]++;
			count[str2[i]]--;
			
		}
		
		if(str1.length!=str2.length) {
			return false;
		}
		
		for(i=0;i<NO_OF_CHARS;i++) {
			if(count[i]!=0) {
				return false;
			}
			//return true;
		}
		
		return true;
	}

}
