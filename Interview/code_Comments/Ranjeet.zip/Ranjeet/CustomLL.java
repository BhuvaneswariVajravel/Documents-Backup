package com.coforge.test;

public class CustomLL {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * LL list=new LL(); list.insertFirst(3); list.insertFirst(4);
		 * list.insertFirst(8); list.insertFirst(19); list.insertLast(10);
		 * list.insertMiddle(21, 3); list.display(); list.delete(2); list.display();
		 */
		/*
		 * DLL list=new DLL(); list.insertFirst(3); list.insertFirst(4);
		 * list.insertFirst(8); list.insertFirst(19); list.display(); list.insert(8,
		 * 65); System.out.println(); list.display();
		 */
		
		/*CLL list=new CLL();
		list.insert(48);
		list.insert(7);
		list.insert(76);
		list.insert(19);
		list.display();
		list.delete(76);
		list.display();*/
		
		LL list=new LL(); 
		list.insertLast(1); 
		list.insertLast(2);
		list.insertLast(4); 
		list.insertLast(5); 
		list.insertLast(6);
		list.insertLast(7);
		list.insertLast(4);
		//list.insertLast(10);
		//list.display();
		//list.insertRec(88, 3);
		list.display();
		list.insertMiddle(77,3);
		list.display();
		//list.swapAlternateNumber();
		//list.display();
		//list.duplicates();
		//list.display();
		
	}
	
	

}
 