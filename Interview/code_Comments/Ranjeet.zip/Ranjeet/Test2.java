package com.coforge.test;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println(sum(0,1));
		
		String up="applebnf";
		System.out.println(up.substring(5));

	}
	
	static int sum(int a, int b) {
		if(a<b) {
			return a+b;
		}
		a=a+b;
		return a;
	}

}
