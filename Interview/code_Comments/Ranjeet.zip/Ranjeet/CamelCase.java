package com.coforge.test;

public class CamelCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String st="I am writing code";
		
		System.out.println(camelCase(st));

	}
	
	static String camelCase(String str) {
		
		char[] ch = str.toCharArray();
		
		int res=0;
		int cnt=0;
		for(int i=0;i<ch.length;i++) {
			
			if(ch[i] == ' ') {
				cnt++;
				ch[i+1]=Character.toUpperCase(ch[i+1]);
				continue;
			}
			else {
				ch[res++]=ch[i];
			}
			
		}
		
		return String.valueOf(ch, 0, ch.length-cnt);
		
	}

}
