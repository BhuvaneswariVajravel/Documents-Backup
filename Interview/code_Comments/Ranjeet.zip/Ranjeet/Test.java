package com.coforge.test;

import java.util.Arrays;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("Test");
		//System.out.println(reverseNum(15652782));
		
		/*
		 * int[] arr= {2,4,67,23,8,5,89,10,88,77}; int start=0; int end=arr.length-1;
		 * 
		 * while(start<end) { swapNum(arr, start, end); start++; end--; }
		 * //System.out.println(Arrays.toString(arr));
		 * 
		 * int[][] array= {{2,34,6}, {8,56,7,3}, {7,45} }; int target=3;
		 */
		
		
		
		//System.out.println(search(array, target));
		
		//System.out.println(sumArray(array));
		
		int[] a= {-10,-7,0,2,3,7,9,11,23,33,44,56,89};
		int tar=0;
		//System.out.println(ceilinginArray(a, tar));
		
		System.out.println(reverString("abcdefgh"));
		
		
	}
	
	public static String reverString(String str) {
		
		String nstr = "";
		
		//char[] ch=str.toCharArray();
		
		
		for(int i=0;i<str.length();i++) {
			char ch=str.charAt(i);
			nstr=ch+nstr;
		}
		return nstr;
	}
	
	public static int reverseNum(int number) {
		int reverse = 0;
		while(number != 0)   
		{  
		int remainder = number % 10;  
		reverse = reverse * 10 + remainder;  
		number = number/10;  
		}
		return reverse; 
	}
	
	static void swapNum(int[] arr, int start,int end) {
		int temp;
		temp = arr[start];
		arr[start]=arr[end];
		arr[end]=temp;
	}
	
	static boolean search(int[][] arr,int target) {
		for(int i=0;i<arr.length;i++) { 
			for(int j=0;j<arr[i].length;j++) {
				if(arr[i][j]==target) {
					return true;
				}
		}
			//return false;
		}
		return false;
	}
	
	static int sumArray(int[][] arr) {
		int result=0;
		
		for(int i=0;i<arr.length;i++) {			
			int sum=0;
				for(int j=0;j<arr[i].length;j++) {
					sum=sum+arr[i][j];
				}
				if(sum>result) {
					result=sum;
				}
			}
		
		
		return result;
	}

	static int binarySearch(int[] arr,int target) {
		int start=0;
		int end=arr.length-1;
		int result=0;
		
		while(start<=end){
			int mid=(start+end)/2;
			if(arr[mid]==target) {
				result=mid;
				return result;
			}else if(arr[mid]<target) {
				start=mid+1;
			}else {
				end=mid-1;
			}
		}		
		return -1;
	}
	
	static int ceilinginArray(int[] arr, int target) {
		int start=0;
		int end=arr.length-1;
		int ans=0;
		boolean isAsc=false;
		if(arr[start]<arr[end]) {
			isAsc=true;
		}else {
			isAsc=false;
		}
		
		while(start<=end) {
			int mid=start+(end-start)/2;
			if(arr[mid]==target) {
				ans=mid;
				//return ans;
				//if(arr[ans]==arr[])
				return arr[ans];
			}
			if(isAsc) {
				if(arr[mid]<target) {
					
					start=mid+1;
				}else {
					end=mid-1;
				}
				
			}else {
				if(arr[mid]<target) {
					end=mid-1;
					
				}else {
					start=mid+1;
				}
			}
		}
		
		/*
		 * if(arr[start]<target) { ans=arr[start+1];
		 * 
		 * }else if(arr[start]>target){ ans=arr[start-1]; } else { ans=arr[start]; }
		 */
		
		
		
		return arr[start];
	}

}
 