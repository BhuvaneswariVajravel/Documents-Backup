package com.coforge.test;

import java.util.*;

public class SortbyNumberOfOccurance {

	static Integer[] arr = { 2, 5, 2, 8, 5, 6, 8, 8 };
	public static void main(String[] args) {
		sortbyoccurance(Arrays.asList(arr));

	}
	
	public static void sortbyoccurance(List<Integer> list) { 
		
		Map<Integer,Integer> mapcount=new HashMap<Integer,Integer>();
		Map<Integer,Integer> mapindex=new HashMap<Integer,Integer>();
		int len=arr.length;
		for(int i=0;i<len;i++) {
			if(mapcount.containsKey(arr[i])) {
				mapcount.put(arr[i], mapcount.get(arr[i])+1);
			}else {
				mapcount.put(arr[i], 1);
				mapindex.put(arr[i], i);
			}
		}
		
		Collections.sort(list,new Comparator<Integer>(){
				public int compare(Integer n1, Integer n2) {
					int freq1=mapcount.get(n1);
					int freq2=mapcount.get(n2);
					if(freq1!=freq2) {
						return freq2-freq1;
					}else {
						return mapindex.get(n1)-mapindex.get(n2);
				}
				
		}
		});
	System.out.println(list);
	}

}
