package com.coforge.test;

import java.util.LinkedList;

public class PalindromSingleLinkedList {

	public static void main(String[] args) {
		PalindromLL palin=new PalindromLL();
		
		palin.insertFirst('a');
		palin.insertFirst('b');
		palin.insertFirst('c');
		palin.insertFirst('c');
		palin.insertFirst('b');
		palin.insertFirst('a');
		
		palin.printList(palin.head);	
		
		
		System.out.println(palin.isPalindrom(palin.head));

	}	

}

class NewNode{
	NewNode next;
	char data;
	public NewNode(char data) {
		this.data=data;
	}
	public NewNode(char data, NewNode next) {
		this.data=data;
		this.next=next;
	}
}

class PalindromLL{
	NewNode second_half;
	NewNode head;	
	NewNode slow_pointer;
	NewNode fast_pointer;
	
	boolean isPalindrom(NewNode NewNode) {
		slow_pointer=head;
		fast_pointer=head;
		NewNode middle=null;
		NewNode prev_slow_pointer=null;
		while(fast_pointer!=null && fast_pointer.next!=null) {
			fast_pointer=fast_pointer.next.next;
			slow_pointer=slow_pointer.next;
			prev_slow_pointer=slow_pointer;
		}
		
		if(fast_pointer!=null) {
			middle=slow_pointer;
			prev_slow_pointer=slow_pointer.next;
		}
		
		second_half=slow_pointer;
		prev_slow_pointer.next=null;
		
		reverse();
		boolean res=compareList(head,second_half);
		
		
		
		return res;
	}

	private boolean compareList(NewNode head1, NewNode head2) {
		NewNode temp1=head1;
		NewNode temp2=head2;
		
		while(temp1!=null && temp2!=null)
			if(temp1.data==temp2.data) {
				temp1=temp1.next;
				temp2=temp2.next;
			}else {
				return false;
			}
		
		if(temp1==null && temp2==null) {
			return true;
		}
		
		return false;
		
	}

	public void reverse() {
		NewNode prev=null;
		NewNode curr=second_half;
		NewNode next;
		
		while(curr!=null) {
			next=curr.next;
			curr.next=prev;
			prev=curr;
			curr=next;
		}
	
		second_half=prev;
		
	}
	
	public void insertFirst(char data){       
        NewNode new_node = new NewNode(data);        
        new_node.next = head;       
        head = new_node;
    } 
   
    void printList(NewNode node){
        while (node != null) {
            System.out.print(node.data + "->");
            node = node.next;
        }
        System.out.println("NULL");
    }
}
