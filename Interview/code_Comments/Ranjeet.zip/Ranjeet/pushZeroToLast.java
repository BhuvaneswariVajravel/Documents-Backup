package com.coforge.test;

public class pushZeroToLast {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] arr= {1,0,2,3,4,0,0,9,8,7,0,45,67};
		pushZero(arr, arr.length);
		
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+ " ");
		}

	}
	
	public static void pushZero(int[] arr,int size) {
		
		int count = 0;
		for(int i=0;i<size;i++) {
			if(arr[i]!=0)
			arr[count++]=arr[i];
		}
		
		while(count<size) {
			arr[count++]=0;
		}
	}

}
