package com.coforge.test;

import java.util.Vector;

public class NoOfIslands {

	public static void main(String[] args) {
		int grid[][]= new int[][]{{1,1,0,0},
				   				  {0,0,1,0},
				   				  {0,0,1,0},
				   				  {1,0,0,0}};
				   				  
	   System.out.println(numOfIslands(grid));

	}
	
	public static int numOfIslands(int[][] grid) {
		
		int rows=grid.length;
		if(rows==0)
			return 0;
		
		int cols=grid[0].length;
		
		int no_of_islands=0;
		
		for(int i=0;i<rows;i++) {
			for(int j=0;j<cols;j++) {
				if(grid[i][j]==1) {
					mark_current_island(grid,i,j,rows,cols);
					no_of_islands++;
				}
			}
		}
		return no_of_islands;
		
	}

	private static void mark_current_island(int[][] grid, int x, int y, int r, int c) {
		if(x<0 || x>=r || y<0 || y>=c || grid[x][y]!=1)
			return;
		
		grid[x][y] = 2;
		
		mark_current_island(grid, x+1, y, r, c);
		mark_current_island(grid, x, y+1, r, c);
		mark_current_island(grid, x-1, y, r, c);
		mark_current_island(grid, x, y-1, r, c);		
		
	}

}
