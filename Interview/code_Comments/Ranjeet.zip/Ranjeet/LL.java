package com.coforge.test;

public class LL {

	Node head;
	Node tail;
	int size;
	public void insertFirst(int val) {
		Node node=new Node(val);
		node.next=head;
		head=node;
		if (tail==null) {
			tail=head;
		}
		size++;
	}
	public void insertLast(int val) {
		if(tail==null) {
			insertFirst(val);
			return;
		}
		Node node = new Node(val);
		tail.next=node;
		tail=node;
		size++;
		
	}
	
	public void insertMiddle(int val, int index) {
		Node temp=head;
		for(int i=1;i<index;i++) {
			temp=temp.next;
		}
		
		//Node node=new Node(temp.next,val);
		Node node=new Node(val);
		//
		node.next=temp.next;
		temp.next=node;
		//temp.next=node.next;
		
		
	}
	
	public void display() {
		Node temp;
		temp=head;
		while(temp!=null) {
			
			System.out.print(temp.val + "->");
			temp=temp.next;
			//size++;
		}
		System.out.println("END");
		
	}
	
	public int delete(int index) {
		
		Node node=get(index-1);
		int value=node.next.val;
		node.next=node.next.next;
		
		return value;
	}
	
	public Node get(int size) {
		
		Node temp=head;
		for(int i=0;i<size;i++) {
			temp=temp.next;
		}
		
		return temp; 
	}
	
	void insertRec(int val, int index) {
		head=insertRec(val, index,head);
	}
	
	private Node insertRec(int val, int index, Node node) {
		int count=0;
		if(index==0) {
			System.out.println("inside if block");
			Node temp=new Node(node,val);
			size++;
			return temp;
		}
		count++;
		node.next=insertRec(val, index-1, node.next);
		System.out.println("after node.next"+ " " +count);
		return node;
	}
	
	public void duplicates() {
		Node node=head;
		
		while(node.next!=null) {
			if(node.val==node.next.val) {
				node.next=node.next.next;
				size--;
			}
			else {
				node=node.next;
			}
		}
		tail=node;
		tail.next=null;
	}
	
	public boolean hasCircle() {
		Node fast=head;
		Node slow=head;
		while(fast!=null && fast.next!=null) {
			fast=fast.next.next;
			slow=slow.next;
			if(fast==slow) {
				return true;
			}
		}		
		
		return false;
	}
	
	public int circleLength() {
		//int len=0;
		Node fast=head;
		Node slow=head;
		while(fast!=null && fast.next!=null) {
			fast=fast.next.next;
			slow=slow.next;
			if(fast==slow) {
				Node temp=slow;
				int len=0;
				do {
					temp=temp.next;
					len++;
				}while(temp!=slow);
				return len;
			}
		}	
		
		return 0;
	}
	
	
	
	boolean compareList(Node head1,Node head2) {
		
		Node temp1=head1;
		Node temp2=head2;
		
		while(temp1.next!=null && temp2.next!=null) {
			if(temp1.val==temp2.val) {
				temp1=temp1.next;
				temp2=temp2.next;
			}else {
				return false;
			}
				
		}
		if(temp1.next==null && temp2.next==null) {
			return true;
		}
		
		return false;
		
	}
	
	
	
	
	
	public Node insertRecs(int val, Node node, int index) {
		Node temp=head;
		if(index==0) {
			Node newNode=new Node(node, val);
			return newNode;
		}
		node.next=insertRecs(val, node.next, index-1);
		return node;
	}
	
	public void reverse1() {
		Node curr=head;
		Node prev = null;
		Node next=null;
		
		while(head!=null) {
			next=curr.next;
			curr.next=prev;
			prev=curr;
			curr=next;
			
		}
		head=prev;
		
	}
	void reverse() {
		Node current =  head;
		Node prev = null;
		Node next = null;
		
		while(current.next!=null) {
			next=current.next;
			current.next=prev;
			prev=current;
			current=next;
		}
		head=prev;	
	}
	
	public boolean comparList(Node node1, Node node2) {
		Node head1=node1;
		Node head2=node2;
		while(head1!=null && head2!=null) {
			if(head1.val!=head2.val) {
				return false;
			}
			head1=head1.next;
			head2=head2.next;
		}
		if(head1.next==null && head2.next==null) {
			return true;
		}
		
		return false;
	}
	
	public void swapalter(Node node) {
		Node prev=head;
		Node curr=head.next;
		Node next=null;
		
		while(curr!=null) {
			next=curr.next;
			curr.next=prev;
			prev.next=next.next;
			
			prev=next;
			curr=prev.next;
		}
	}
	
void swapAlternateNumber() {
		
		Node prev=head;
		Node curr=head.next;
		
		head=curr;
		
		while(curr!=null) {
			Node next=curr.next;
			curr.next=prev;
			prev.next=next.next;
			
			prev=next;
			curr=prev.next;
		}
		//return node;
		
		/*
		 * Node temp=head; while(temp!=null) { Node tempo=temp; temp.next=temp;
		 * temp=tempo; temp=temp.next.next; }
		 */
	}
}

class Node{
	Node next;
	int val;
	public Node(int val) {
		super();
		this.val = val;
	}
	public Node(Node next, int val) {
		super();
		this.next = next;
		this.val = val;
	}
	
}

