package com.coforge.test;

import java.util.*;

public class LRUTest {

	public static void main(String[] args) {
		LRUTest lru=new LRUTest(4);
		lru.refer(1);
		lru.refer(2);
		lru.refer(5);
		lru.refer(3);
		lru.display();
		System.out.println();
		lru.refer(4);
		lru.display();
		System.out.println();
		lru.refer(2);
		lru.display();

	}
	
	private Deque<Integer> DoublyQueue;
	private HashSet<Integer> set;
	private final int Cache_size;
	
	public LRUTest(int capacity) {
		DoublyQueue = new LinkedList<>();
		set=new HashSet<>();
		Cache_size=capacity;
	}
	
	public void refer(int val) {
		
		if(set.contains(val)) {
			DoublyQueue.remove(val);
		}else {
			if(DoublyQueue.size()==Cache_size) {
				int last=DoublyQueue.removeLast();
				set.remove(last);
			}
		}
		
		DoublyQueue.push(val);
		set.add(val);
		
	}
	
	public void display() {
		Iterator<Integer> it=DoublyQueue.iterator();
		while(it.hasNext()) {
			System.out.print(it.next() + " ");
		}
	}
	

}
