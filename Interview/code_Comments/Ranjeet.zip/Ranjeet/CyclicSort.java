package com.coforge.test;

import java.util.Arrays;

public class CyclicSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr= {3,2,5,1,4};
		cyclicSort(arr);
		System.out.println(Arrays.toString(arr));
	}
	
	static void cyclicSort(int[] arr) {
		int i=0;
		int n=arr.length;
		while(i<n) {
			int correct=arr[i]-1;
			if(arr[correct]!=arr[i]) {
				swap(arr,i,correct);
			}
			else {
				i++;
			}
		}
	}
	
	static void swap(int[] arr, int first, int last) {
		int temp=arr[first];
		arr[first]=arr[last];
		arr[last]=temp;
	}

}
