
public class FactorialClass {
	public int factorial(int number) {
		int factorial =0;
		if(number==1) {
			return factorial=1;
		}else {
			factorial = number*factorial(number-1);
		}
		
		return factorial;
	}
}
