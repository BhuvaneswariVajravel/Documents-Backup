
public class MainTest {

	public static void main(String[] args) {
		FactorialClass fac = new FactorialClass();
		System.out.println(fac.factorial(4));
		//print first two of Fibonacci series
		System.out.println(n1 +","+n2);
		FibonacciSeries.getFibonacciSeries(5);
		
	}

}
