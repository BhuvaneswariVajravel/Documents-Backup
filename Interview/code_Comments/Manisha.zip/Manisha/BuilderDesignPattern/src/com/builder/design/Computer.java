package com.builder.design;

public class Computer {
	private String ram;
	private String hd;
	private String motherBoard;
	private String keyBoard;
	private String mouse;

	//

	public Computer(String ram, String hd) {
		super();
		this.ram = ram;
		this.hd = hd;
	}

	public Computer(String ram, String hd, String motherBoard) {
		super();
		this.ram = ram;
		this.hd = hd;
		this.motherBoard = motherBoard;
	}

	public Computer(String ram, String hd, String motherBoard, String keyBoard, String mouse) {
		super();
		this.ram = ram;
		this.hd = hd;
		this.motherBoard = motherBoard;
		this.keyBoard = keyBoard;
		this.mouse = mouse;
	}

//
	public Computer(ComputerBuilder builder) {
		this.hd = builder.getHd();
		this.keyBoard = builder.getKeyBoard();
		this.motherBoard = builder.getMotherBoard();
		this.mouse = builder.getMouse();
		this.ram = builder.getRam();
	}

	public String getRam() {
		return ram;
	}

	public String getHd() {
		return hd;
	}

	public String getMotherBoard() {
		return motherBoard;
	}

	public String getKeyBoard() {
		return keyBoard;
	}

	public String getMouse() {
		return mouse;
	}

}
