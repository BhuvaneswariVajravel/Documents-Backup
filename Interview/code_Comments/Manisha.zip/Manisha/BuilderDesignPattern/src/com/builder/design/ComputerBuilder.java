package com.builder.design;

public class ComputerBuilder {
	private String ram;
	private String hd;
	private String motherBoard;
	private String keyBoard;
	private String mouse;
	public ComputerBuilder() {}
	public ComputerBuilder(String ram, String motherBoard) {
		this.ram=ram;
		this.motherBoard=motherBoard;
	}
	 ComputerBuilder setHD(String hd) {
		 this.hd = hd;
		 return this;
	 }
	 ComputerBuilder setKeyBoard(String keyBoard) {
		 this.keyBoard = keyBoard;
		 return this;
	 }
	 ComputerBuilder setram(String ram) {
		 this.ram = ram;
		 return this;
	 }
	 ComputerBuilder setMotherBoard(String motherBoard) {
		 this.motherBoard = motherBoard;
		 return this;
	 }
	 ComputerBuilder setMouse(String mouse) {
		 this.mouse = mouse;
		 return this;
	 }
	 public String getRam() {
		return ram;
	}
	public String getHd() {
		return hd;
	}
	public String getMotherBoard() {
		return motherBoard;
	}
	public String getKeyBoard() {
		return keyBoard;
	}
	public String getMouse() {
		return mouse;
	}

	Computer build() {
		 return new Computer(this);
	 }
}
