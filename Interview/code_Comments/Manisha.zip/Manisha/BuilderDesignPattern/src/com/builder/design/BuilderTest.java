package com.builder.design;

public class BuilderTest {

	public static void main(String[] args) {
	Computer computer = new ComputerBuilder("32GB","MOTHERBOARD").setHD("320TB").setMouse("OPTICAL MOUSE").build();
	System.out.println(computer.getHd());
	}

}
