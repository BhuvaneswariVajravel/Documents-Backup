package com.coforge.clientTest;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class StringReverse {
	public static String reverse(String string) {
		// StringBuilder reverse() method
		StringBuilder reverseString = new StringBuilder(string);
		reverseString.reverse();
		System.out.println(reverseString);

		// StringBuffer reverse() method
		StringBuffer reverse = new StringBuffer(string);
		reverse.reverse();
		System.out.println(reverse);

		// Collections reverse() method
		Character[] charArrayObject = string.chars().mapToObj(c -> (char)c).toArray(Character[]::new); 
		List<Character> listChars = Arrays.asList(charArrayObject);
		Collections.reverse(listChars);
		System.out.println(listChars.toString());
			
		return reverseString.toString();
	}
}
