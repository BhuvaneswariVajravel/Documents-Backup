package com.coforge.clientTest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PairOfElementsOfGivenSum {
	public static List<Integer> getPairOfElementsOfGivenSum(Integer[] array, int sum){
		List<Integer> list = Arrays.asList(array);
		List<Integer> pairOfElements = new ArrayList<>();
		for (Integer integer : list) {
			int pairElement = sum-Integer.valueOf(integer);
			if(list.contains(pairElement) && list.indexOf(pairElement)!=list.indexOf(integer) && !pairOfElements.contains(integer)) {
				pairOfElements.add(integer);
				pairOfElements.add(pairElement);
			}
		}
		
		System.out.println(pairOfElements);
		return pairOfElements;
	}
}
