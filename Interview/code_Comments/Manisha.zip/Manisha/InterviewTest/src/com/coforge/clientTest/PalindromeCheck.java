package com.coforge.clientTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PalindromeCheck {
	public static boolean checkPalindrome(List<Character> list) {
		List<Character> newList = new ArrayList<>();
		newList.addAll(list);
		Collections.reverse(list);
		System.out.println(newList.equals(list));
		return newList.equals(list);
	}
	public static void main(String[] args) {
		List<Character> charList = new ArrayList<>();
		charList.add('a');
		charList.add('b');
		charList.add('c');
		charList.add('b');
		charList.add('a');
		checkPalindrome(charList);
	}

}
