package com.coforge.clientTest;

public class RecursiveExample {
	static int factorial( int n ) {
        if (n != 0)  // termination condition
            return n * factorial(n-1); // recursive call
        else
            return 1;
    }

	public static void main(String[] args) {
		 int number = 4, result;
	        result = factorial(number);
	        System.out.println(number + " factorial  = " + result);
	}
	
	/*
	 * Why not to use recursion: It is usually slower due to the overhead of
	 * maintaining the stack. It usually uses more memory for the stack.
	 * 
	 * Why to use recursion: Recursion adds clarity and (sometimes) reduces the time
	 * needed to write and debug code (but doesn't necessarily reduce space
	 * requirements or speed of execution). Reduces time complexity. Performs better
	 * in solving problems based on tree structures.
	 */

}
