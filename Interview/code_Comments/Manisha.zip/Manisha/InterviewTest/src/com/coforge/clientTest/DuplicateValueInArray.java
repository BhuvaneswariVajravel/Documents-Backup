package com.coforge.clientTest;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DuplicateValueInArray {
	public static void removeDuplicate(Integer[] intArray) {
		List<Integer> integerList = Arrays.asList(intArray);
		Set<Integer> set = new HashSet<>();
		int sizeOfSet = set.size();
		set.addAll(integerList);
		Integer[] arrayAfterRemoveDuplicate = new Integer[sizeOfSet];
		int i=0;
		for (Integer integer : set) {
			arrayAfterRemoveDuplicate[i]=integer;
			i++;		
		}
		
	}
}
