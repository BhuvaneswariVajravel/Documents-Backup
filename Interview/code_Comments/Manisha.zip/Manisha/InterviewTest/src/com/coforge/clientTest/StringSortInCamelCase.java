package com.coforge.clientTest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class StringSortInCamelCase {
	public static String sort(String str) {
		StringBuilder result = new StringBuilder();
		int length = str.length();
		List<Character> charListLowerCase = new ArrayList<>();
		List<Character> charListUpperCase = new ArrayList<>();
		char[] charArrayLowerCase = new char[length];
		char[] charArrayUpperCase = new char[length];
		char[] charArray = str.toCharArray();
		for (char c : charArray) {
			
			if(c>='a' && c<='z') {
				charListLowerCase.add(new Character(c));
				
			}
			if(c>='A' && c<='Z') {
				charListUpperCase.add(new Character(c));
			}
		}
		Collections.sort(charListLowerCase);
		Collections.sort(charListUpperCase);
		
		System.out.println(charArrayUpperCase);
		System.out.println(charArrayLowerCase);
		int m=0; int n=0;
		for (int k=0; k<length;k++) {
			
			if(charArray[k]>='a' && charArray[k]<='z') {
				result.insert(k, charListLowerCase.get(m));
				m++;
			}
			if(charArray[k]>='A' && charArray[k]<='Z') {
				result.insert(k,  charListUpperCase.get(n));
				n++;
			}
		}
		System.out.println(result);
		return result.toString();
	}
}
