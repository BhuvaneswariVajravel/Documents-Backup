package com.coforge.clientTest;

import java.util.Arrays;
import java.util.stream.Collectors;

public class SortArray {

	public static void sortArray(Integer[] array) {
		// Arrays class sort() method
		Arrays.sort(array);
		Arrays.asList(array).stream().forEach(i->System.out.println(i));
		
		// Stream API sort() method
		Arrays.asList(array).stream().sorted().collect(Collectors.toList());
		System.out.println(Arrays.asList(array).stream().sorted().collect(Collectors.toList()));
	}
	
	/*
	 * public static void sortArrayUsingBasic(Integer[] array) { for (int i = 1; i <
	 * array.length; i++) { int previousIndexData ; if(array[i]<array[i-1]) {
	 * previousIndexData=array[i]; array[i]=array[i-1]; } }
	 * 
	 * }
	 */}
