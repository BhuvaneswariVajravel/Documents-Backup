package com.coforge.clientTest;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.coforge.model.Employee;

public class SortListByNoOfOccurence {
	public static void sort(List<Integer> list) {	
		Map<Integer, Long> map = list.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		System.out.println(map);
		List<Entry<Integer, Long>> sortedMap = map.entrySet().stream().sorted(Comparator.comparing(e->e.getValue())).collect(Collectors.toList());
		System.out.println(sortedMap);
	}
	
	public static void employeeSort(List<Employee> listEmp) {
		listEmp.sort(Comparator.comparing(Employee::getId).thenComparing(Employee::getName).thenComparing(Employee::getSalary));
		System.out.println(listEmp.toString());
	}
	
}
