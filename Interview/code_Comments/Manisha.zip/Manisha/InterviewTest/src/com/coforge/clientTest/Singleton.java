package com.coforge.clientTest;

import java.io.Serializable;

public class Singleton implements Serializable,Cloneable{
		
	private static final long serialVersionUID = 1L;
	public static Singleton instance ;
	private Singleton() {
		
	}

	private static Singleton getInstance() {
		if(instance == null) {
			instance = new Singleton();
		}
		return instance ;
	}
	private static Singleton getInstance2() {
		if(instance == null) {
			synchronized(Singleton.class) {
				if(instance == null) {
				instance = new Singleton();
				}
				}
		}
		return instance;
	}
	protected Object clone() throws CloneNotSupportedException{
		return instance ;
	}
	protected Object readResolve() {
		return instance ;
	}


	}


