package com.coforge.clientTest;

import java.util.Arrays;

public class NthLargestElementInArray {
	public static int getNthLargestElement(int[] intArray, int no) {
		Arrays.sort(intArray);
		System.out.println("3rd largest element in array: "+intArray[intArray.length-no]);
		return intArray[intArray.length-no];
	}
}
