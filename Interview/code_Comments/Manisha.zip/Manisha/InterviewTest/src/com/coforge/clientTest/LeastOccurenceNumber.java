package com.coforge.clientTest;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.stream.Collectors;

public class LeastOccurenceNumber {
	public static int findLeastOccurenceNo(List<Integer> list) {
		Map<Integer, Long> map = list.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		Optional<Entry<Integer, Long>> min = map.entrySet().stream().min(new EntryComparator());
		System.out.println("min count: "+min);
				
		return min.get().getKey();
	}
	/*
	 * public static int findLeastOccurenceNoBasicMethod(List<Integer> list) {
	 * Map<Integer, Integer> sortedMap = new TreeMap(new MapComparator()); for
	 * (Integer integer : list) { if(!sortedMap.containsKey(integer)) {
	 * sortedMap.put(integer, new Integer(1)); }else { sortedMap.put(integer, new
	 * Integer(sortedMap.get(integer)+1)); } } Set<Map.Entry<Integer, Integer>>
	 * entrySet = sortedMap.entrySet(); Set<Integer> keySet = sortedMap.keySet();
	 * List<Integer> resultList = keySet.stream().collect(Collectors.toList());
	 * System.out.println(resultList.get(0)); return resultList.get(0); }
	 */
}
