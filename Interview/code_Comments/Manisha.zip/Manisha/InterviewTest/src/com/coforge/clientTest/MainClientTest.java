package com.coforge.clientTest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.coforge.model.Employee;

public class MainClientTest {

	public static void main(String[] args) {
		List<Integer> numbers = new ArrayList<>();
		numbers.add(1);
		numbers.add(2);
		numbers.add(3);
		numbers.add(3);
		numbers.add(3);
		numbers.add(5);
		numbers.add(5);
		numbers.add(2);
		numbers.add(9);
		numbers.add(0);
		int result = LeastOccurenceNumber.findLeastOccurenceNo(numbers);
		System.out.println(result);
		//LeastOccurenceNumber.findLeastOccurenceNoBasicMethod(numbers);
		Integer[] array = {1,0,2,6,9,5,4};
		int[] intArray ={1,0,2,6,9,5,4};
		int largestNo = NthLargestElementInArray.getNthLargestElement(intArray, 3);
		System.out.println("3rd largest element in array: "+largestNo);  // 3rd largest element in array
		PairOfElementsOfGivenSum.getPairOfElementsOfGivenSum(array, 8);
		StringReverse.reverse("manisha");
		Integer[] duplicateArray = {1,2,6,6,2,9,5,4}; //
		DuplicateInArray.findFirstDuplicate(duplicateArray);
		
		SortListByNoOfOccurence.sort(numbers);
		
		DuplicateInArray.findSecondDuplicate(duplicateArray);
		StringSortInCamelCase.sort("gEeksfOrgEEkS");
		Employee emp1= new Employee("manisha", "0099890", 3423423L);
		Employee emp2= new Employee("KUMARI", "0099897", 1423423L);
		Employee emp3= new Employee("MEENAKSHI", "0099812", 7423423L);
		Employee emp4= new Employee("YATIKA", "0069890", 3423423L);
		Employee emp5= new Employee("YUKTI", "0069890", 7423423L);
		Employee emp6= new Employee("YUKTI", "1069890", 7423423L);
		List<Employee> empList = new ArrayList<>();
		empList.add(emp5);
		empList.add(emp4);
		empList.add(emp3);
		empList.add(emp2);
		empList.add(emp1);
		empList.add(emp6);
		SortListByNoOfOccurence.employeeSort(empList);
	}

}
