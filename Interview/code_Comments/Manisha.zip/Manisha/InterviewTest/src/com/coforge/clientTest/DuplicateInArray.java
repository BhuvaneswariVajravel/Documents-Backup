package com.coforge.clientTest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class DuplicateInArray {
	public static Integer findFirstDuplicate(Integer[] intArray) {
		Integer firstDuplicate = null;

		List<Integer> listInteger = Arrays.asList(intArray);
		Map<Integer, Integer> map = new LinkedHashMap<>();
		/*
		 * listInteger.stream().forEach(i-> {if(map.get(i)==null){ map.put(i, 1); } else
		 * { firstDuplicate = i;
		 * System.out.println("first duplicate no is: "+firstDuplicate); break; } }
		 * 
		 * );
		 */

		for (Integer integer : listInteger) {
			/*
			 * if(listInteger.contains(integer)) { listInteger.remove(integer);
			 * if(listInteger.contains(integer)) { firstDuplicate = integer; break; } }
			 */

			if (map.get(integer) == null) {
				map.put(integer, 1);
			} else {
				firstDuplicate = integer;
				System.out.println("first duplicate no is: " + firstDuplicate);
				break;
			}
		}

		return firstDuplicate;
	}

	public static Integer findSecondDuplicate(Integer[] intArray) {
		Integer secondDuplicateNo = null;
		int count =0;
		List<Integer> listInteger = Arrays.asList(intArray);
		Map<Integer, Integer> map = new LinkedHashMap<>();

		for (Integer integer : listInteger) {

			if (map.get(integer) == null) {
				map.put(integer, 1);
			} else {
				count++;
				secondDuplicateNo = integer;				
				if(count==2) {
					System.out.println("2nd duplicate no is: " + secondDuplicateNo);
					break;
				}
			}
		}

		return secondDuplicateNo;
	}
}
