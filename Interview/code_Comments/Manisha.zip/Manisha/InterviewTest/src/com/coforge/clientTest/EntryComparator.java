package com.coforge.clientTest;

import java.util.Comparator;
import java.util.Map.Entry;

public class EntryComparator implements Comparator<Entry<Integer,Long>>{

	@Override
	public int compare(Entry<Integer, Long> o1, Entry<Integer, Long> o2) {

		return o1.getValue().compareTo(o2.getValue());
	}

}
