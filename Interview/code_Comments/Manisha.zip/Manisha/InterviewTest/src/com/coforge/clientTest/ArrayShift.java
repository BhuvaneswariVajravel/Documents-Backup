package com.coforge.clientTest;

public class ArrayShift {

	public static void main(String[] args) {
		// int[] arrayNum = {2,5,1,0,0,8,0,3};
		//int[] arrayNum = {0,0,8,0,3,0,8};
		int[] arrayNum = { 9, 0, 0, 0, 0, 3, 0, 8 };
		int lastIndexOfInt = 0;
		// Shifting all 0 to right
		for (int i = 0; i < arrayNum.length - 1; i++) {
			if (arrayNum[i] != 0) {
				if (lastIndexOfInt == 0 && i == 0) {
				} else {
					lastIndexOfInt = lastIndexOfInt + 1;
				}
			} else if (arrayNum[i] == 0 && arrayNum[i + 1] != 0) {
				if (lastIndexOfInt == 0 && arrayNum[0] == 0) {
					arrayNum[lastIndexOfInt] = arrayNum[i + 1];
				} else {
					arrayNum[lastIndexOfInt + 1] = arrayNum[i + 1];
					lastIndexOfInt = lastIndexOfInt + 1;
				}
				arrayNum[i + 1] = 0;
			}
		}
		for (int i : arrayNum) {
			System.out.println(i);
		}

		/*
		 * Shifting all 1 to left int[] a={1,2,3,1,1,2,2,1,3,2,1}; int
		 * indexOfOneFromEnd; for(int i=a.length-1;i>0;i--){ if(a[a.length-1]==1 &&
		 * indexOfOneFromEnd==0){ indexOfOneFromEnd = a.length-1; } if(a[i]==1 &&
		 * a[i-1]!=1){ a[i]=a[i-1]; a[i-1]=1; indexOfOneFromEnd=i-1;
		 * 
		 * }
		 * 
		 * }
		 */
	}

}