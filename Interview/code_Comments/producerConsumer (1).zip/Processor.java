package producerConsumer;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Random;

/*
* {@code synchronized} keyword is used for exclusive accessing. To make a
* method {@code synchronized}, simply add the {@code synchronized} keyword to its
* declaration.<be>
* Then no two invocations of synchronized methods on the same object can
* interleave with each other.
* <br>
* Synchronized statements must specify the object that
* provides the intrinsic lock. When {@code synchronized(this)} is used, you
* have to avoid to synchronizing invocations of other objects' methods.

* {@link Object#wait()} tells
* the calling thread to give up the lock and go to sleep (not polling) until
* some other thread enters the same lock and calls {@link Object#notify()}.
* <br>

* {@link Object#notify()} wakes up the first thread that called wait() on
* the same object.
* <br><br>
*/

public class Processor {

	private final int LIMIT = 10;

	private Object lock = new Object();

	private LinkedList<Integer> list = new LinkedList<>();

	public void produce() throws InterruptedException {
		// TODO Auto-generated method stub
		int value = 0;

		while (true) {
			synchronized (lock) {
				if (list.size() == LIMIT) {
					lock.wait();
				}
				list.add(value);

				System.out.println("Producer added: " + value + " queue size is " + list.size());
				value++;
				lock.notify();

			}
		}

	}

	public void consume() throws InterruptedException {
		// TODO Auto-generated method stub
		Random random = new Random();
		while (true) {
			synchronized (lock) {
				if (list.size() == 0) {
					lock.wait();
				}
				int value = list.removeFirst();

				System.out.print("Removed value by consumer is: " + value);
				System.out.println(" Now list size is: " + list.size());

				lock.notify();
			}
			Thread.sleep(random.nextInt(1000)); // force producer fill the queue to LIMIT_SIZE
		}

	}

}
