package adapterDesignpattern;

public interface MainDriver {
	
	void showDetail();

}
