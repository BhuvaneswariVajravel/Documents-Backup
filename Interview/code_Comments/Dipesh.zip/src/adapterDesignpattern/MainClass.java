package adapterDesignpattern;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		IdeDriver ideObj = new IdeDriver();
		
		MainDriver mainDriver = new CheomeDriver(ideObj);
		
		mainDriver.showDetail();

	}

}
