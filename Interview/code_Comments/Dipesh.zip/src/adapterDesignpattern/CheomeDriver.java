package adapterDesignpattern;

//This is Adapter class
public class CheomeDriver implements MainDriver{

	IdeDriver idedriver;
	
	public CheomeDriver(IdeDriver ideObj) {
		// TODO Auto-generated constructor stub
		this.idedriver = ideObj;
	}
	
	@Override
	public void showDetail() {
		// TODO Auto-generated method stub
		idedriver.showInfo();
		
	}

}
