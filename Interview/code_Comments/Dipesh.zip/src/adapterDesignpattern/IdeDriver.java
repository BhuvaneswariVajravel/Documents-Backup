package adapterDesignpattern;

public class IdeDriver {
	
	void showInfo() {
		System.out.println("This is IdeDriver method.");
	}

}
