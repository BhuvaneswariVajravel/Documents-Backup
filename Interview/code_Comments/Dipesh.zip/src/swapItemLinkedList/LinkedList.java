package swapItemLinkedList;

class Node {
	int item;
	Node next;

	public Node(int item) {
		// TODO Auto-generated constructor stub
		this.item = item;
		this.next = null;
	}
}

public class LinkedList {
	Node head;

	public void printList() {
		// TODO Auto-generated method stub
		Node tempNode = head;
		while (tempNode != null) {
			System.out.println("Item : " + tempNode.item);
			tempNode = tempNode.next;
		}

	}

	public void push(int newItem) {
		// TODO Auto-generated method stub
		Node newNode = new Node(newItem);

		newNode.next = head;

		head = newNode;

	}

	public void Swap(int x, int y) {
		if (x == y)
			return;

		Node prevX = null;
		Node curX = head;
		// find 1st item
		while (curX != null && curX.item != x) {
			prevX = curX;
			curX = curX.next;
		}

		Node prevY = null;
		Node curY = head;
		// find 2nd item
		while (curY != null && curY.item != y) {
			prevY = curY;
			curY = curY.next;
		}

		// Either x or y item isn't present.
		if (curX == null || curY == null) {
			return;
		}

		// if X is not head element
		if (prevX != null) {
			prevX.next = curY;
		} else // if X is head element
		{
			head = curY;
		}

		// if Y in not head element
		if (prevY != null) {
			prevY.next = curX;
		} else {
			head = curX;
		}

		// swap next pointer
		Node tempNode = curX.next;
		curX.next = curY.next;
		curY.next = tempNode;

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList list = new LinkedList();

		list.push(10);
		list.push(12);
		list.push(15);
		list.push(20);
		list.push(22);
		list.push(25);

		list.printList();

		System.out.println("--------before swap---------");

		list.Swap(10, 25);

		System.out.println("-----------After Swap-----------------");
		
		list.printList();

	}

}
