package dsaCode;

import java.util.HashMap;
import java.util.Map;

//Find pair of of elements in Array with given sum?
public class TargetPair {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 3, 7, 9, 2 };

		int target = 11;

		int[] result = pair(arr, target);

		System.out.println(result[0]);
		System.out.println(result[1]);

	}

	static int[] pair(int nums[], int target) {
		Integer l = nums.length;

		Map<Integer, Integer> map = new HashMap<Integer, Integer>();

		for (int i = 0; i < l; i++) {
			Integer rem = map.get(nums[i]);

			if (rem == null) {
				int diff = target - nums[i];
				map.put(diff, i);

			} else {
				int ans[] = { rem, i };
				return ans;

			}

		}

		return null;
	}

}
