package dsaCode;

import java.util.HashSet;
import java.util.Set;

public class firstDuplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer arr[] = {1,2,4,5,4,8,9};
		int l = arr.length;
		
		Set<Integer> set = new HashSet<Integer>();
		
		for(int i = 0 ; i < l ; i++) {
			if(!set.add(arr[i])) {
				System.out.println(arr[i]);
				break;
			}
		}

	}

}
