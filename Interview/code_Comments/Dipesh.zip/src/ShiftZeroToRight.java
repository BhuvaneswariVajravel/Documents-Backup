
//shift all 0 to right and also preserving position of non-zero items


public class ShiftZeroToRight {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = { 5, 0, 0, 4, 6, 0, 0, 3, 2, 1, 0 };
		int l = arr.length;
		int tmp = 0;
		for (int i = 0; i < l; i++) {
			for (int j = i + 1; j < l; j++) {
				if (arr[i] == 0) {
					tmp = arr[i];
					arr[i] = arr[j];
					arr[j] = tmp;
				}
			}
		}

		for (int i = 0; i < l; i++) {
			System.out.println(arr[i]);
		}

	}

}
