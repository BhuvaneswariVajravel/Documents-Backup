import java.util.HashMap;
import java.util.Map;

public class AngramGoodProgramm {
	
	public static void main(String args[]) {
		System.out.println(isAnagram("mary", "army"));
		}

		public static boolean isAnagram(String s1, String s2) {
		return createMap(s1).equals(createMap(s2));
		}

		public static Map<Character, Integer> createMap(String str){
		Map<Character, Integer> map = new HashMap<Character, Integer>();

		for(char c: str.toLowerCase().toCharArray()) {
		Integer i = map.get(c);
		map.put(c, i==null?1:i+1);
		}

		return map;
		}

}
