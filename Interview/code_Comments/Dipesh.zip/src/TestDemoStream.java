import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

class Employee{
	
	public Employee(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}
	String name;
	int id;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Name::"+name + " Id::"+id;
	}
}

public class TestDemoStream {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//List<String> list = Arrays.asList( "Chennai","Ajmer","Delhi","Mumbai","zomba","Agra","Banglore","Kolkata");
	
		List<Employee> empList = new ArrayList<Employee>();
		
		empList.add(new Employee("Raj",2));
		empList.add(new Employee("Aju",23));
		empList.add(new Employee("Ganu",25));
		empList.add(new Employee("aja",1));
		
		//Comparator<Employee> cmp = (str1,str2)->  str1.getName().compareTo(str2.getName());
	
		Comparator<String> cmp = (str1,str2)->  str1.compareTo(str2);
		
		//List<Employee> rst = empList.stream().sorted(cmp).collect(Collectors.toList());
		
		List<String> rst = empList.stream().map(emp->emp.getName()).sorted(cmp).collect(Collectors.toList());
		
		rst.forEach(System.out::println);
		

	}

}
