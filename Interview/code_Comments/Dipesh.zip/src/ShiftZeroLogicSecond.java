
public class ShiftZeroLogicSecond {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arrayNumber = { 1, 3, 0, 5, 0, 3, 2, 0, 7 };
		for (int i = 0; i < arrayNumber.length; i++) {
			int dataAtIndexI = 0;
			if (arrayNumber[i] != 0) {
				dataAtIndexI = i;
				continue;
			}

			if (arrayNumber[i] == 0 && arrayNumber[i + 1] != 0) {
				if (dataAtIndexI == 0) {
					arrayNumber[dataAtIndexI] = arrayNumber[i + 1];
				}
				arrayNumber[dataAtIndexI + 1] = arrayNumber[i + 1];
				dataAtIndexI = dataAtIndexI + 1;
				arrayNumber[i + 1] = 0;
			}
		}
		for (int i = 0; i < arrayNumber.length; i++) {
			
			System.out.println(arrayNumber[i]);
		}

	}

}
