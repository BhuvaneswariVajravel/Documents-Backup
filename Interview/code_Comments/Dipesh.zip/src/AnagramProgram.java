
public class AnagramProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1= "peek";
		String str2= "keep";
		
		
		System.out.println(isAnagram(str1.replaceAll("\\s", ""), str2.replaceAll("\\s", "")));

	}
	
	public static boolean isAnagram(String str1,String str2) {
		int l= str1.length();
		boolean flag = false;
		int cnt[] = new int[l];
		int tmp=1;
		if(str1.length() != str2.length()) {
			return false;
		}
		
		for(int i =0 ; i < l; i++ ) {
			for(int j = 0; j <l ; j++) {
				if(str1.charAt(i)==str2.charAt(j)) {
					cnt[i]= 1;
					
				}
				
			}
			
		}
		
		for(int i = 0 ; i < cnt.length ; i++ ) {
			if(cnt[i] == 0 ) {
				return false;
			}
		}
		 

		
		return true;
	}

}
