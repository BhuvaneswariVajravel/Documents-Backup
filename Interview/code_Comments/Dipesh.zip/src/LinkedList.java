
class Node {
	char ch;
	Node next = null;

	public Node() {
		// TODO Auto-generated constructor stub
	}

	public Node(char ch) {
		// TODO Auto-generated constructor stub
		this.ch = ch;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Data::" + ch;
	}
}

public class LinkedList {

	static Node head = null;
	Node middle = null;

	Node insertAtbegin(char data) {

		Node newNode = new Node(data);

		if (head == null) {
			head = newNode;
		} else {
			newNode.next = head;
			head = newNode;
		}

		return newNode;
	}

	void traverseList() {
		Node newNode = head;
		// newNode.next= head;

		while (newNode != null) {
			System.out.println(newNode.ch);
			newNode = newNode.next;
		}
	}

	public static void main(String[] args) {
		LinkedList list = new LinkedList();

		list.head = new Node('N');

		list.head.next = new Node('I');

		list.head.next.next = new Node('T');

		list.head.next.next.next = new Node('I');

		list.head.next.next.next.next = new Node('N');

		// list.traverseList();

		// list.reverse();

		if (list.isPalindromMidLogic())
			System.out.println("List is Palindrom");
		else
			System.out.println("List is Not Palindrom");

	}

	// extra logic optional one.
	public boolean isPalindromMidLogic() {

		Node nodeA = head;
		Node nodeB = nodeA.next;

		while (nodeB != null && nodeB.next != null) {
			nodeA = nodeA.next;
			if (nodeB.next.next == null) {
				nodeB = nodeB.next;
			} else {
				nodeB = nodeB.next.next;
			}

		}

		// System.out.println(nodeA.ch);
		// System.out.println(nodeB.ch);

		middle = nodeA;

		reverse(nodeA);

		return differ();

	}

	private boolean differ() {
		// TODO Auto-generated method stub

		Node mainHead = head;
		Node midHead = middle.next;

		while (midHead != null) {
			if (!(mainHead.ch == midHead.ch)) {
				return false;
			}
			mainHead = mainHead.next;
			midHead = midHead.next;
		}

		return true;
	}

	public void reverse(Node mid) {

		Node cur = mid.next;
		Node prev = mid;
		Node temp = null;

		while (cur != null) {

			temp = cur.next;
			cur.next = prev;
			prev = cur;
			cur = temp;
		}
		mid.next.next = null;
		mid.next = prev;

	}

}
