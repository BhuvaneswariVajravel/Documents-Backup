package factoryDesignPattern;

public interface Calculation {

	public double calculate(double num1, double num2);

}
