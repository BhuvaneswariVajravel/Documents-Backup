package factoryDesignPattern;

import java.util.Optional;

public class Test {
	public static void main(String[] args) {
		double num1 = 2;
		double num2 = 3;

		CalculateFactory factory = new CalculateFactory();
		Calculation calc = factory.getCalculate("xyz");
		// System.out.println("result : "+calc.calculate(num1, num2));
		Optional<Calculation> result = Optional.ofNullable(calc);
		System.out.println(result.isPresent());
		if (result.isPresent()) {
			System.out.println("result : " + calc.calculate(num1, num2));
		}
	}
}
