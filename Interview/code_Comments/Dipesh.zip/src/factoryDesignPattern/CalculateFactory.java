package factoryDesignPattern;

public class CalculateFactory {
	public Calculation getCalculate(String type) {
		Calculation calcValue = null;
		if (type.toLowerCase().equals("add")) {
			calcValue = new Add();
		} else if (type.toLowerCase().equals("sub")) {
			calcValue = new Subtract();
		} else if (type.toLowerCase().equals("mul")) {
			calcValue = new Multiply();
		} else {
			System.out.println("not a valid input");
		}
		return calcValue;
	}
}
