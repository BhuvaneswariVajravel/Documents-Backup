import java.util.HashMap;
import java.util.Map;

public class hashSetMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Map<String,Integer> map = new HashMap<String, Integer>();
		
		System.out.println(map.put("One", 1));
		
		System.out.println(map.put("One", 2));
		
		//System.out.println(map);
	}

}
