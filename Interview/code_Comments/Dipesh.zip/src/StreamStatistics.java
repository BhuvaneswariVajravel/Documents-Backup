import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;

public class StreamStatistics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Integer> list= Arrays.asList(2,4,5,6,8);
		
		IntSummaryStatistics summaryStatistics= list.stream().mapToInt(x->x).summaryStatistics();
		
		System.out.println("max::"+ summaryStatistics.getMax());
		System.out.println("min::"+ summaryStatistics.getMin());
		System.out.println("avg::"+ summaryStatistics.getAverage());
		System.out.println("sum::"+ summaryStatistics.getSum());

	}

}
