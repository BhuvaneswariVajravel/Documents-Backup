package singletonDesignPattern;

import java.io.Serializable;

//By using clone() we can break the singleton object functionality 
// and create another object with different hashcode
//to avoid this we need to overwrite the clone method by throwing clone not supported execption
public class Singleton implements Cloneable, Serializable {

	private static Singleton instance;

	private Singleton() {
		// fix for reflection
		if (instance != null) {
			throw new IllegalStateException("Object cannot be created with reflection");
		}
		System.out.println("Singleton object created");
	}

	public static Singleton getInstance() {
		if (instance == null) {
			instance = new Singleton();
		}
		return instance;
	}

	// used for not breaking singleton for serialization
	protected Object readResolve() {
		return instance;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		// below statement break the singleton functionality
		// return super.clone();

		// fix to avoid breaking singleton functionality
		throw new CloneNotSupportedException();
	}
}
