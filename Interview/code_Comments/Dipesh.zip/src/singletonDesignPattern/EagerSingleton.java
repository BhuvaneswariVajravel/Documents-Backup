package singletonDesignPattern;

public class EagerSingleton {

	private static EagerSingleton instance = new EagerSingleton();

	private EagerSingleton() {
		System.out.println("EagerSingleton object created");
	}

	public static EagerSingleton getInstance() {
		return instance;
	}

}
