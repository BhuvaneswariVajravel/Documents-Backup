package singletonDesignPattern;

public class SyncronizedSingleton {

	private static SyncronizedSingleton instance;

	private SyncronizedSingleton() {
		System.out.println("SyncronizedSingleton object created");
	}

	synchronized public static SyncronizedSingleton getInstance() {
		if (instance == null) {
			instance = new SyncronizedSingleton();
		}
		return instance;
	}
}
