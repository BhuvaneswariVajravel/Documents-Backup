

class MytaskClass implements Runnable{
	
	String task;
	
	Object lockA = new Object();
	Object lockB = new Object();
	Object lockC = new Object();
	
	public MytaskClass(String task) {
		// TODO Auto-generated constructor stub
		this.task = task;
	}
	
	public void doTaskA() {
		// TODO Auto-generated method stub

		 synchronized (lockA) {
		
	
			System.out.println(task+Thread.currentThread()+"::" );
		
		try {
			Thread.sleep(1);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}
	
	public void doTaskB() {
		// TODO Auto-generated method stub

		 synchronized (lockB) {
	
			System.out.println(task+Thread.currentThread()+"::" );
		
		try {
			Thread.sleep(1);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}
	
	public void doTaskC() {
		// TODO Auto-generated method stub

		 synchronized (lockC) {
		

			System.out.println(task+Thread.currentThread()+"::" );
		
		try {
			Thread.sleep(1);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		

		for(int i = 0; i < 1000;i++) {
			doTaskA();
			doTaskB();
			doTaskC();
		}

		
	}
	
}


public class ThreadDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        System.out.println("Starting ...");
        long start = System.currentTimeMillis();
		
		MytaskClass mt1 = new MytaskClass("Tas1");
		MytaskClass mt2 = new MytaskClass("Tas2");
		MytaskClass mt3 = new MytaskClass("Tas3");
		
		   Thread t1 = new Thread(mt1);
		   Thread t2 = new Thread(mt1);
		   Thread t3 = new Thread(mt1);
		    t1.start();
		    t2.start();
		    t3.start();
		    
	        try {
	            t1.join();
	            t2.join();
	            t3.join();
	        } catch (InterruptedException ignored) {}
	        
	        long end = System.currentTimeMillis();
	        
	        System.out.println("Time taken: " + (end - start));
	        
	        System.out.println("End");

	}

}
