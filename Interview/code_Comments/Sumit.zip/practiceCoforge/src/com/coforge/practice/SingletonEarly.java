package com.coforge.practice;

import java.io.Serializable;

public class SingletonEarly implements Serializable{
		 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//your code of singleton  
    protected Object readResolve() {  
        return getA();  
    }  
		private static SingletonEarly obj=new SingletonEarly();//Early, instance will be created at load time  
		 private SingletonEarly(){}  
		   
		 public static SingletonEarly getA(){  
		  return obj;  
		 }  
		  
		 public void doSomething(){  
		 //write your code  
		 }  
}
