package com.coforge.practice;

/*
 * sort Employee on basis of Name, Salary and joining Date
 */
import java.util.Date;
//Implement Comparable to sort Employee on basis of Name, Salary and joining Date
class Employee implements Comparable<Employee> {
  String name;
  Integer salary;
  Date JoiningDate;

  public Employee() {
  }

  public Employee(String n, Integer f, Date d) {
         name = n;
         salary = f;
         JoiningDate = d;
  }

  public String toString() {
         return "\n name=" + name + ",salary=" + salary + ",JoiningDate="
                      + JoiningDate;
  }

  public int compareTo(Employee o) {
         return this.name.compareTo(o.name) + (this.salary.compareTo(o.salary))
                      + (this.JoiningDate.compareTo(o.JoiningDate));
  }
}
