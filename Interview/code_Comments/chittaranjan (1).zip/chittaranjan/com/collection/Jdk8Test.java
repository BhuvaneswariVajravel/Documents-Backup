package com.collection;

import java.util.Arrays;

public class Jdk8Test {
public static void main(String[] args) {
	int[] arr = { 10, 7, 8, 9, 1, 5 };
	Arrays.sort(arr);
	System.out.println("arr:"+Arrays.toString(arr));
	//Arrays sum
	
}
}
