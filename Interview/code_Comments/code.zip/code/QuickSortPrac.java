package com.coforge.test;

import java.util.Arrays;

public class QuickSortPrac {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] arr= {3,6,7,3,4,5,9,1,0};
		
		selectionSort(arr, 0, arr.length-1);
		
		System.out.println(Arrays.toString(arr));

	}
	
	static void selectionSort(int[] arr,int low, int high) {
		
		if(low>=high) {
			return;
		}
		
		int s=low;
		int e=high;
		int m=s+(e-s)/2;
		int pivot=arr[m];
		while(s<=e) {
			while(arr[s]<pivot) {
				s++;
			}
			while(arr[e]>pivot) {
				e--;
			}
			if(s<=e) {
				int temp=arr[e];
				arr[e]=arr[s];
				arr[s]=temp;
				s++;
				e--;
				
			}
		}
		selectionSort(arr, s, high);
		selectionSort(arr, low, e);
		
		
	}

}
