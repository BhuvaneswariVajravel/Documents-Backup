package com.coforge.test;

public class MoveOneLeft {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a={1,2,3,1,1,2,2,1,3,2,1};
		
		moveOnetoLeft(a);
		
		for(int i=0;i<a.length;i++) {
			System.out.print(a[i]+" ");
		}
		
	}
	
	public static void moveOnetoright(int[] arr) {
		
		int n=arr.length;
		int j=0;
		for(int i=0;i<n;i++) {
			if(arr[i]!=1) {
				arr[j++]=arr[i];
			}
		}
		while(j<n) {
			arr[j++]=1;
		}
		/*
		 * for(int i=0;i<n;i++) { if(arr[i]!=1) { arr[j++]=arr[i]; } }
		 */		
	}
	
public static void moveOnetoLeft(int[] arr) {
		
		int writeIndex=arr.length-1;
		int readIndex=arr.length-1;
		
		while(readIndex>=0) {
			if(arr[readIndex]!=1) {
				arr[writeIndex]=arr[readIndex];
				writeIndex--;
			}
			readIndex--;
		}
		while(writeIndex>=0) {
			arr[writeIndex]=1; 
			writeIndex--;
		}
		/*
		 * for(int i=0;i<n;i++) { if(arr[i]!=1) { arr[j++]=arr[i]; } }
		 */		
	}

}
