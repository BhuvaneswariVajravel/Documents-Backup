package com.coforge.test;

public class CLL {
	
	Node head=null;
	Node tail=null;

	private class Node{
		int val;
		Node next;
		public Node(int val, Node next) {
			super();
			this.val = val;
			this.next = next;
		}
		public Node(int val) {
			super();
			this.val = val;
		}
		
		
	}
	
	public void insert(int value) {
		Node node=new Node(value);
		if(head!=null) {
			node.next=head;
			tail.next=node;
			tail=node;
		}else {
			head=node;
			tail=node;
		}
	}
	
	public void display() {
		Node temp=head;
		if(head!=null) {
			do {
				System.out.print(temp.val + "->") ;
				temp=temp.next;
			}while(temp!=head);
		}
		System.out.println("HEAD");
		
	}

	public void delete(int value) {
		
		Node node=head;
		if(node ==null) {
			return;
		}
		if(node.val==value) {
			head=head.next;
			tail.next=head;
		}
		
		do {
			Node temp=node.next;
			if(temp.val==value) {
				node.next=temp.next;
				break;
			}
			node=node.next;
		}while(node!=head);
		
	}
	
	
}
