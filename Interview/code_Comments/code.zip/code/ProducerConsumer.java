package com.coforge.test;

import java.util.LinkedList;

public class ProducerConsumer {

	public static void main(String[] args) throws InterruptedException {

		final PC pc=new PC();

		Thread thread1=new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					pc.producer();
				} catch (InterruptedException e) {					
					e.printStackTrace();
				}
				
			}
		}
				
	);

		Thread thread2=new Thread(new Runnable() {
					
					@Override
					public void run() {
						try {
							pc.consumer();
						} catch (InterruptedException e) {					
							e.printStackTrace();
						}
						
					}
				}
						
			);
		
		thread1.start();thread2.start();
		thread1.join();thread2.join();
	}
	
	public static class PC{
		LinkedList<Integer> list=new LinkedList<>();
		int capacity=3;
		public void producer() throws InterruptedException {
			int val=0;
			while(true) {
				synchronized (this) {
					if(list.size()==capacity)
						wait();
					System.out.println("Producer Produced: "+val);
					list.add(val++);
					
					notify();
					
					Thread.sleep(1000);
					
				}
			}
		}
		
		public void consumer() throws InterruptedException {
			
			while(true) {
				synchronized (this) {
					if(list.size()==0)
						wait();
					
					int val=list.removeFirst();
					System.out.println("Consumer Consumed: "+val);
					notify();
					
					Thread.sleep(1000);
					
				}
			}
		}
		
	}

}
