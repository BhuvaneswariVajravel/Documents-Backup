package com.coforge.test;

public class StringTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str="bcadgadd";
		
		skipA("",str);
		
		String str1="vbbvapplehj";
		
		//System.out.println(skipApple(str1));
		
		subSeq("", "abc");

	}
	
	// Q: remove all the 'a' from string. taken 2 string as arguments. p (process string) is empty and up(unprocess string)
	//is actual given string. take an elemnets from up and compare if 'a' then don't add in p otherwise add in p recursively.
	// up.substring(index) will give the remaining string from index
	
	static void skipA(String p,String up) {
		
		//String str="";
		if(up.isEmpty()) {
			System.out.println(p);
			return;
		}
		
		char ch=up.charAt(0);
		
		if(ch=='a') {
			skipA(p,up.substring(1));
			
		}else {
			//ch+skipA(p.substring(1));
			skipA(p+ch,up.substring(1));
		}
		//return str;
		
		//return "";
	}
	
	static String skipApple(String p) {
		if(p.isEmpty()) {
			return "";
		}
		
		if(p.startsWith("apple")) {
			return skipApple(p.substring(5));
		}else {
			return p.charAt(0)+skipApple(p.substring(1));
		}
		
		//return null;
		
	}
	
	static void subSeq(String p, String up) {
		if(up.isEmpty()) {
			System.out.println(p);
			return;
		}
		
		char ch=up.charAt(0);
		
		subSeq(p + ch, up.substring(1));
		subSeq(p, up.substring(1));
	}

}
