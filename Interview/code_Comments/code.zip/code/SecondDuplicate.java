package com.coforge.test;

import java.util.*;
import java.util.Map.Entry;

public class SecondDuplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] arr= {1,2,4,5,2,8,3,3,4,5,6,78,8,5};
		seconDupHash(arr);	

	}
	
	static void seconDup(int[] arr) {
		
		int count=0;
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<i-1;j++) {
				if(arr[i]==arr[j]) {
					count++;
					if(count==2) {
						System.out.println("SeconDup: "+arr[i]);
					}
				}
			}
		}
	}
	
	static void seconDupHash(int[] arr) {
		
		Map<Integer,Integer> map=new HashMap<Integer,Integer>();
		int count=0;
		for(int i=0;i<arr.length;i++) {
			if(map.containsKey(arr[i])) {
				map.put(arr[i], map.get(arr[i])+1);
				count++;
				if(count==3) {
					System.out.println("Second Duplicate : " +arr[i]);
				}
				
			}else {
				map.put(arr[i], 1);
			}
		}
				
	}

}
