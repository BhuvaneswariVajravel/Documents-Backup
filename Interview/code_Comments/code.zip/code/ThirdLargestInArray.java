package com.coforge.test;

public class ThirdLargestInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] arr= {7,6,18,5,6,9,10,27};
		System.out.println(thirdLargestinArray(arr));

	}
	
	static int thirdLargestinArray(int[] arr) {
		
		int first =arr[0];
		int second=Integer.MIN_VALUE;
		int third=Integer.MIN_VALUE;
		
		for(int i=1;i<arr.length;i++) {
			if(arr[i]>first) {
				third=second;
				second=first;
				first=arr[i];
			}else if(arr[i]>second) {
				third=second;
				second=arr[i];
			}else if(arr[i]>third){
				third=arr[i];
			}
		}
		
		return third;
	}
	//return third;

}
