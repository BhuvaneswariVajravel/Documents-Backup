package com.coforge.test;

import java.util.Arrays;

public class RemoveDup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] arr= {1,2,5,4,2,3};
		int len=removeDup(arr);
		for(int i=0;i<len;i++) {
			System.out.print(arr[i]+ " ");
		}
	}
	
	static int removeDup(int[] arr) {
		int len=arr.length;
		
		for(int i=0;i<len;i++) {
			for(int j=i+1;j<len;j++) {
				if(arr[i]==arr[j]){
					arr[j]=arr[len-1];
					//j--;
					len--;
				}
			}
		}
		return len;
	}
	

}
