package com.coforge.test;

import java.util.HashSet;

public class FirstOccurance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String string="geeksforgeeks";
		char[] ch=string.toCharArray();
		System.out.println(firstOccurance(ch));
	}
	
	static char firstOccurance(char[] str) {
		
		HashSet<Character> set=new HashSet();
		for(int i=0;i<str.length;i++) {
			
			char c= str[i];
			
			if(set.contains(c)) {
				return c;
			}else {
				set.add(c);
			}
			
		}

 		return '\0';
	}

}
