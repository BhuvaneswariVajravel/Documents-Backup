package com.coforge.test;

import java.util.concurrent.*;

public class ExecutorServiceEx {

	public static void main(String[] args) {
		
		//FixedThreadPool
		ExecutorService service = Executors.newFixedThreadPool(4);
		for(int i=0;i<10;i++) {
			service.submit(new Task());
		}
		System.out.println("Thread Name: "+Thread.currentThread().getName());
		
		//CachedThreadPool
		ExecutorService cacheservice = Executors.newCachedThreadPool();
		for(int i=0;i<10;i++) {
			cacheservice.submit(new Task());
		}
		
		//ScheduledThreadPool
		ScheduledExecutorService scheduleservice=Executors.newScheduledThreadPool(10);
		scheduleservice.schedule(new Task(), 10, TimeUnit.SECONDS);
		scheduleservice.scheduleAtFixedRate(new Task(), 15, 10, TimeUnit.SECONDS);
		scheduleservice.scheduleWithFixedDelay(new Task(), 15, 10, TimeUnit.SECONDS);
		
		//SingleExecutorThread
		/*
		 * ExecutorService singleService=Executors.newScheduledThreadPool(4); for(int
		 * i=0;i<10;i++) { singleService.submit(new Task()); }
		 * System.out.println("SingleThread Executor Thread Name: "+Thread.currentThread
		 * ().getName());
		 */
		
		service.shutdown();
		cacheservice.shutdown();
		scheduleservice.shutdown();
	}
	
	static class Task implements Runnable{

		@Override
		public void run() {
			System.out.println("Thread Name: " +Thread.currentThread().getName());
			
		}
		
	}

}
