package com.coforge.test;

public class DLL {
	Node head;
	Node tail;
	int size;
	
	private class Node{
		Node next;
		Node prev;
		int val;
		public Node(int val) {
			super();
			this.val = val;
		}
		public Node(Node next, int val) {
			super();
			this.next = next;
			this.val = val;
		}
		public Node(Node next, Node prev, int val) {
			super();
			this.next = next;
			this.prev = prev;
			this.val = val;
		}
		
		
	}
	
	public Node findValue(int value) {
		
		Node temp=head;
		while(temp!=null) {
			if(temp.val==value) {
				return temp;
			}
			temp=temp.next;
		}
		
		return null;
	}
	
	public Node insertFirst(int value) {
		Node node=new Node(value);
		if(head==null) {
			node.next=null;
			node.prev=null;
		}
		node.next=head;
		if(head!=null) {
			head.prev=node;
		}
		//node.next.prev=node;
		node.prev=null;
		head=node;
		return node;
	}
	
	public void display() {
		Node temp;
		temp=head;
		Node last=null;
		while(temp!=null) {
			
			System.out.print(temp.val + "->");
			last=temp;
			temp=temp.next;
			//size++;
		}
		System.out.println("END");
		System.out.println("Reverse Direction");
		while(last!=null) {
			System.out.print(last.val + "->");
			last=last.prev;
		}
		
	}
	
	public Node insert(int value,int val) {
		Node temp=findValue(value);
		Node node=new Node(val);
		node.next=temp.next;
		temp.next=node;
		node.prev=temp;
		if(node.next!=null) {
			node.next.prev=node; 
		}
		
		return temp;
	}
}


