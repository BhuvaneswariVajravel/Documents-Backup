package com.coforge.test;

public class RemoveDuplicates {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int[] arr= {1,4,6,1,2,12,8,2,1};
		int[] arr= {5,5,5,5,51,1,2,3,4,3,4};
		int j=removeDuplicates(arr);
		
		for(int i=0;i<j;i++) {
			System.out.print(arr[i]+ " ");
		}

	}
	
	static int removeDuplicates(int[] arr) {
		
		int n= arr.length;
		int firstelemnt=0;
		
		if(n==0 || n==1) {
			return n;
		}
		
		int j=0;
		for(int i=0;i<n-1;i++) {
			if(arr[i]!=arr[i+1]) {
				arr[j++]=arr[i];
			}else {
				firstelemnt=arr[i];
				
				System.out.println(firstelemnt);
			}
		}
		arr[j++]=arr[n-1];
		return j;
	}

}
