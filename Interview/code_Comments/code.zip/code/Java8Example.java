package com.coforge.test;

import java.util.*;
import java.util.stream.*;

public class Java8Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Stream filter Example
		List<String> strList = Arrays.asList("abc", "", "bcd", "", "defg", "jk"); 
		long count = strList.stream() .filter(x -> x.isEmpty()) .count();
		
		
		
		System.out.println(count);
		
		List<String> G7 = Arrays.asList("USA", "Japan", "France", "Germany", "Italy", "U.K.","Canada"); 
		String G7Countries = G7.stream() .map(x -> x.toUpperCase()) .collect(Collectors.joining(", "));
		
		System.out.println(G7Countries);

		//foreach jabva 8 example
		 List<String> gamesList = new ArrayList<String>();  
	        gamesList.add("Football");  
	        gamesList.add("Cricket");  
	        gamesList.add("Chess");  
	        gamesList.add("Hocky");  
	        System.out.println("------------Iterating by passing lambda expression--------------");  
	        gamesList.forEach(x -> System.out.println(x));  
	          
		

	}

}
