package com.coforge.test;

public class StaticTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	static class Test{
		
		static void method() {
			
		}
	}

}

