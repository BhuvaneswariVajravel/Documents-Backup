package com.coforge.test;

import java.util.Map.Entry;
import java.util.*;

public class LeastFrequent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] arr= {1,3,2,1,2,2,3,1,3,3};
		int n=arr.length;
		System.out.println(leastFrequentHash(arr, n));

	}

	static int leastFrequent(int[] arr,int n) {
		
		Arrays.sort(arr);
		int min_count=n+1;
		int res=-1;
		int curr_count=1;
		
		for(int i=1;i<n;i++) {
			if(arr[i]==arr[i-1]) {
				curr_count++;
			}
			else {
				if(curr_count<min_count) {
					min_count=curr_count;
					res=arr[i-1];
				}
				curr_count=1;
			}
		}
		
		if(curr_count<min_count) {
			min_count=curr_count;
			res=arr[n-1];
		}
		return res;
	}
	
	
	static int leastFrequentHash(int arr[],int n)
    {
         
        // Insert all elements in hash.
        Map<Integer,Integer> count = new HashMap<Integer, Integer>();
                    
        for(int i = 0; i < n; i++)
        {
            int key = arr[i];
            if(count.containsKey(key))
            {
                int freq = count.get(key);
                freq++;
                count.put(key,freq);
            }
            else
                count.put(key,1);
        }
         
        // find min frequency.
        int min_count = n+1, res = -1;
        for(Entry<Integer,Integer> val : count.entrySet())
        {
            if (min_count >= val.getValue())
            {
                res = val.getKey();
                min_count = val.getValue();
            }
        }
         
        return res;
    }
}
