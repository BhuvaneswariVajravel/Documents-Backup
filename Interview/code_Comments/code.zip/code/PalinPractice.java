package com.coforge.test;

public class PalinPractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String arr="abbbnn";
		
		System.out.println(isPalin(arr));

	}
	
	static boolean isPalin(String arr) {
		
		int i= 0;
		int j=arr.length()-1;
		
		while(j>=i) {
			if(arr.charAt(i)!=arr.charAt(j)) {
				return false;
			}
			i++;
			j--;
		}
		
		return true;
	}

}
