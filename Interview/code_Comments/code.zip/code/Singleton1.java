package com.coforge.test;

import java.io.Serializable;

class TestSingleton extends SuperClass implements Serializable{
	
	private static TestSingleton instance;
	
	private TestSingleton() {
		if(instance!=null) {
			throw new IllegalStateException("Object cannot be created with reflection");
			}
	}
	
	protected Object readResolve() {
		return instance;
		
	}
	
	protected Object clone() throws CloneNotSupportedException{
		return instance;
	}
	
	public static TestSingleton getInstance() {
		if(instance==null) {
			synchronized (TestSingleton.class) {
				if(instance==null) {
					instance=new TestSingleton();
				}
				
			}
		}
		return instance;
	}

}

class SuperClass implements Cloneable{
	
	protected Object clone() throws CloneNotSupportedException{
		return super.clone();
		
	}
	
}

public class Singleton1{
	public static void main(String[] arg) {
		TestSingleton ins1=TestSingleton.getInstance();
		TestSingleton ins2 = null;
		try {
			ins2=(TestSingleton)ins1.clone();
		} catch (CloneNotSupportedException e) {
			
			e.printStackTrace();
		}
		
		System.out.println(ins1.hashCode());
		System.out.println(ins2.hashCode());
		
		
		
		
	}
}
