import java.util.*;

class LinkedList { 
    Node head; // list head 
      //node - linkedlist
    class Node { 
        int data; 
        Node next; 
    
        Node(int d) { data = d; }  //constructor to create a new node
    } 
}

