import java.io.Serializable;

public class SingletonSerialization implements Serializable {
	
	private static final long serialVersionID = 0L;

}
