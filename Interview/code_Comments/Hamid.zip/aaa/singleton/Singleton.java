package com.demo.aaa.singleton;
//Java program for Enum type singleton
public enum Singleton 
{
  INSTANCE;
}