package com.demo.aaa.singleton;

public class SingletonInterfaceDemo {

	//Singleton i;
	
	
	
	
}
