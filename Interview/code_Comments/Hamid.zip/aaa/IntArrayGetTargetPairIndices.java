package com.demo.aaa;

import java.util.ArrayList;
import java.util.List;

public class IntArrayGetTargetPairIndices {

	//array of int
	//target value -> sum of any of 2 int.
	//indices of two ints

	public static void main(String[] args) {
		int[] arr = { 57, 2, 37, 7, 5, 4, 30 }; // {57, 3, 37, 7, 5, 4, 30};
		Integer target = 6;
		List lst2 = getIndices(arr, target);
		System.out.println(lst2);
	}

	public static List getIndices(int[] arr, Integer target) {

	//Logic
	//take i =1 , compare with all
	//if found then return indices
	//else
	//j = i-1 to last

		List<Integer> lsTarget = new ArrayList<>();

		for (int i = 0; i < arr.length - 1; i++) // 0 1 2 3 4 5 6
			for (int j = i; j < arr.length - 1; j++) // i=0, j=0...6 ; i=1, j=1...6
				if (target == (arr[i] + arr[j]) && i != j) {
					lsTarget.add(i);
					lsTarget.add(j);
					return lsTarget;
				}
		return lsTarget;
	}

}