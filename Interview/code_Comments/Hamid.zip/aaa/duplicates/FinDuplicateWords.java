package com.demo.aaa.duplicates;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FinDuplicateWords {

	public static void main(String[] args) {
		Map<String, Integer> dWordMatrix = findDuplicatesWordsWithCount();
		System.out.println(dWordMatrix);
	}

	public static void findDuplicates() {
		String string = "Big black bug bit a big black dog on his big black nose";
		int count;
		string = string.toLowerCase();
		String words[] = string.split(" ");

		System.out.println("Duplicate words in a given string : ");
		for (int i = 0; i < words.length; i++) {
			count = 1;
			for (int j = i + 1; j < words.length; j++) {
				if (words[i].equals(words[j])) {
					count++;
					// Set words[j] to 0 to avoid printing visited word
					words[j] = "0";
				}
			}

			// Displays the duplicate word if count is greater than 1
			if (count > 1 && words[i] != "0")
				System.out.println(words[i]);
		}
	}

	static Map<String, Integer> findDuplicatesWordsWithCount() {
		String string = "Big black bug bit a big black dog dog on his big black nose";
		string = string.toLowerCase(); 
		String words[] = string.split(" ");
		List<String> wordsList = Arrays.asList(words); 
		Map<String, Integer> dWordMatrix = new HashMap<>();
		Map<String, Integer> nodWordMatrix = new HashMap<>();
		//Populate Map with word & WordCount too
		wordsList.stream().forEach(w -> {
			if (dWordMatrix.containsKey(w))
				dWordMatrix.put(w, dWordMatrix.get(w) + 1);
			else
				dWordMatrix.put(w, 1);
		});
		//Create New Map of Only Duplica te Values 
		for (Map.Entry<String, Integer> e : dWordMatrix.entrySet())
			if (e.getValue() > 1)
				nodWordMatrix.put(e.getKey(), e.getValue());

		return nodWordMatrix;
	}

}
