package com.demo.aaa;

// Java program to check if linked list
// is palindrome recursively
import java.util.*;

class PalindromeLinkedList {
	public static void main(String args[]) {
		Node one = new Node(1);
		Node two = new Node(2);
		Node three = new Node(3);
		Node four = new Node(4);
		Node five = new Node(4);
		Node six = new Node(3);
		Node seven = new Node(2);
		Node eight = new Node(1);
		one.ptr = two;
		two.ptr = three;
		three.ptr = four;
		four.ptr = five;
		five.ptr = six;
		six.ptr = seven;
		seven.ptr = eight;
		boolean flag = isPalindrome(one);
		System.out.println("isPalidrome :" + flag);
	}

	static boolean isPalindrome(Node head) {
		Node slow = head;
		boolean ispalin = true;
		Stack<Integer> stack = new Stack<Integer>();

		int c = 0;
		while (slow != null) {
			stack.push(slow.data);
			slow = slow.ptr;
			c = c + 1; // addl
		}

		c = c / 2;
		
		// while (head != null) {
		while (c > 0) { //Optimized
			c=c-1;
			int i = stack.pop();
			if (head.data == i) {
				ispalin = true;
			} else {
				ispalin = false;
				break;
			}
			head = head.ptr;
		}
		return ispalin;
	}
}

class Node {
	int data;
	Node ptr;

	Node(int d) {
		ptr = null;
		data = d;
	}
}
