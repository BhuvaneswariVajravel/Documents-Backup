package com.demo.aaa;

public class StringWordsRev {

	public static void main(String args[]) {
		String str = "Hello World";
		String str2 = revStr(str);
		System.out.println(str2.toString());

	}

	// input -> "Hello World"
	// output -> "Olleh Dlrow"

	public static String revStr(String str1) {
		String str2Rev = "";
		String str = str1.toLowerCase();

		String[] words = str.split(" ");
		System.out.println(words.toString());

		for (int i = 0; i <= words.length - 1; i++) {

			String sTemp = "";
			char[] ch = words[i].toCharArray();
			for (int j = ch.length - 1; j >= 0; j--) {
				sTemp = sTemp + ch[j];
				if (j == ch.length - 1)
					sTemp = sTemp.toUpperCase();
			}

			str2Rev = str2Rev + sTemp;
			str2Rev = str2Rev + " ";
		}

		return str2Rev;
	}

}
