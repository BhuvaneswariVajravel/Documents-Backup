package com.demo.aaa;

public class AllZerosToRight {

	public static void main(String[] args) {

		int[] arr = { 1, 0, 0, 9, 6, 4, 0, 0, 7 };

		int count = 0;
		int j = 0;
		// Logic
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] != 0) {
				arr[j] = arr[i];
				j++;
			} else {
				count++;
			}
		}
		System.out.println(count);

		for (int i = j; i < count + j; i++)
			arr[i] = 0;

		for (int i = 0; i < arr.length; i++)
			System.out.print(arr[i]);

	}

}