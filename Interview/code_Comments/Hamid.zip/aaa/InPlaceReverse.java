package com.demo.aaa;

public class InPlaceReverse {

	public static void main(String args[]) {

		String number = "4567";
		System.out.println("original String: " + number);
		String reversed = inPlaceReverseString(number);
		System.out.println("reversed String: " + reversed);
	}


	public static String inPlaceReverseString(final String input) {
		final StringBuilder builder = new StringBuilder(input);
		int length = builder.length();
		for (int i = 0; i < length / 2; i++) {
			final char current = builder.charAt(i);
			final int otherEnd = length - i - 1;
			builder.setCharAt(i, builder.charAt(otherEnd)); // swap
			builder.setCharAt(otherEnd, current);
		}

		return builder.toString();
	}
}
