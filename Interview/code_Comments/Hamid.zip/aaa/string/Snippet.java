package com.demo.aaa.string;

public class Snippet {

	public static void main(String args[]) {
		String s = " 'hello' , 'world', apple ";
		String ss[] = s.split(",");
		int len = ss.length;
		for (int i = 0; i < len; i++) {
			System.out.println(ss[i].trim());
		}

	}
	
	
	
	

}
