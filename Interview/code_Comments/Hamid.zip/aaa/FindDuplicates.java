package com.demo.aaa;

import java.util.HashSet;
import java.util.Set;

public class FindDuplicates {

	public static void main(String[] args) {

		// int[] input = { 1, 3, 7, 9, 7, 5, 4, 2 };
		// System.out.println(findDuplicates(input));
		
		Integer[] array = { 2, 3, 4, 9, 7, 5, 4, 1 };
		getDuplicates(array);
		
		String[] arrayStr = { "baba","baby","baba","dada" };
		getDuplicates(arrayStr);
		
		
	}

	public static <T extends Comparable<T>> void getDuplicates(T[] array) {
		Set<T> dupes = new HashSet<T>();
		for (T i : array) {
			if (!dupes.add(i)) {
				System.out.println("Duplicate element in array is : " + i);
			}
		}
	}

	@Deprecated //higher complexity
	public static Set<Integer> findDuplicates(int[] input) {
		Set<Integer> duplicates = new HashSet<Integer>();

		for (int i = 0; i < input.length; i++) {
			for (int j = 1; j < input.length; j++) {
				if (input[i] == input[j] && i != j) {
					// duplicate element found
					duplicates.add(input[i]);
					break;
				}
			}
		}

		return duplicates;
	}
}
